import {prisma} from "@/app/lib/prisma"

export default async function ReservationsPage() {
  
  const reservations = await prisma.reservation.findMany({orderBy: {createdAt: "desc"}})
  
  return (
    <>
      <h2 className="mb-4 text-xl">Reservations</h2>
      <p>Total: {reservations.length}</p>
      <pre>{JSON.stringify(reservations, null, 2)}</pre>
    </>
  );
}
